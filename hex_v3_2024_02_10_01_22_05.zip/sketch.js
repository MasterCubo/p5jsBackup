//https://www.youtube.com/watch?v=o9sgjuh-CBM&ab_channel=TheCodingTrain 

let ctx;

function setup() {
  createCanvas(800, 800);
  colorMode(RGB);
  ctx = canvas.getContext('2d');  
  noLoop();

}

function draw() {
  

  background(255);
  rectMode(CORNER)
  strokeWeight(0)
  let bgradient = drawingContext.createLinearGradient(0,0,800,800)
  // CREATE RADIAL GRADIENT IS A THING ‼️‼️
  bgradient.addColorStop(0, color(90))
  bgradient.addColorStop(0.75, color(37.5))
  bgradient.addColorStop(1, color(10))
  ctx.fillStyle = bgradient;
  rect(0,0,800,800, 250)
  
  rectMode(CENTER)
  translate(400,400)
  //textAlign(CENTER)
  //textSize(300)
  //textFont('helvetica')
  //text("cubo",0,50)
  
  let rgradient = drawingContext.createLinearGradient(-300,300,300,-300);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  ctx.fillStyle = color(0,0,0,0);
  strokeWeight(40);
  rotate(PI/2)
  //polygon(0,0,300,6);
  
  
  
  
  
  // cubo
  ctx.fillStyle = color(0,0,0)
  strokeWeight(0)
  // [downleft, left, upleft, upright, right, downright]
  let c =     [1,1,1,1,0,1]
  let u =     [1,1,0,0,1,1]
  let b =     [1,1,1,1,1,1]
  let bstem = [0,1,0,0,0,0]
  let o =     [1,1,1,1,1,1]
  let r = 70;
  let sw = 20;
  polygonSegs(0,  (r*3),      r,6,c,     sw)
  polygonSegs(0,  (r*3-2*r),  r,6,u,     sw)
  polygonSegs(0,  (r*3-4*r),  r,6,b,     sw)
  polygonSegs(-r, (r*3-4*r),  r,6,bstem, sw)
  polygonSegs(0,  (r*3-6*r),  r,6,o,     sw)
  
  
  
  
  
  
  
  
  //ctx.strokeStyle= color("#f00")
  ctx.fillStyle = color(0,0,0,0)
  strokeWeight(10);
  let radius = 350
  let angle = TWO_PI / 6;
  const hexCords = {center:      [0,                   0], 
                    bottom:      [cos(0)*radius,       sin(0)*radius], // bottom
                    bottomleft:  [cos(angle)*radius,   sin(angle)*radius], // bottom left
                    upperleft:   [cos(2*angle)*radius, sin(2*angle)*radius], // upper left
                    top:         [cos(3*angle)*radius, sin(3*angle)*radius], // top 
                    upperright:  [cos(4*angle)*radius, sin(4*angle)*radius], // upper right
                    bottomright: [cos(5*angle)*radius, sin(5*angle)*radius], // bottom right
                   }
  let scalingVector = 1.03
  let gradientScaler1 = 150
  let gradientScaler2 = 300
  translate(hexCords.top[0],hexCords.top[1])
  rgradient = drawingContext.createLinearGradient(-gradientScaler1-hexCords.top[0],gradientScaler1-hexCords.top[1],gradientScaler2-hexCords.top[0],-gradientScaler2-hexCords.top[1]);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  scale(1 / scalingVector)
  quadPoly([hexCords.center, hexCords.bottomright, hexCords.bottom,hexCords.bottomleft])// i hate that javascript has no unpacking syntax
  scale(1 * scalingVector)
  translate(-hexCords.top[0],-hexCords.top[1])

  
  
  translate(hexCords.bottomleft[0], hexCords.bottomleft[1])
  rgradient = drawingContext.createLinearGradient(-gradientScaler1-hexCords.bottomleft[0],gradientScaler1-hexCords.bottomleft[1],gradientScaler2-hexCords.bottomleft[0],-gradientScaler2-hexCords.bottomleft[1]);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  scale(1 / scalingVector)
  quadPoly([hexCords.center, hexCords.top, hexCords.upperright, hexCords.bottomright])
  scale(1 * scalingVector)
  translate(-hexCords.bottomleft[0], -hexCords.bottomleft[1])
  
  
  
  translate(hexCords.bottomright[0], hexCords.bottomright[1])
  rgradient = drawingContext.createLinearGradient(-gradientScaler1-hexCords.bottomright[0],gradientScaler1-hexCords.bottomright[1],gradientScaler2-hexCords.bottomright[0],-gradientScaler2-hexCords.bottomright[1]);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  scale(1 / scalingVector)
  quadPoly([hexCords.center, hexCords.top, hexCords.upperleft, hexCords.bottomleft])
  scale(1 * scalingVector)
  translate(-hexCords.bottomright[0], -hexCords.bottomright[1])

  
  
  
  
  
  
  
  imageMode(CORNERS)
  let img = loadImage('https://assets.editor.p5js.org/65bc4d91dadfd0001a7b075b/ae5a3884-2dec-410f-b66e-26609e805c9a.png')
  tint(255,255,255,100)
  image(img, -400,-400, 400, 400)
  tint(255,255,255,255)
  
  
  
}

function polygon(x, y, radius, npoints) {
  let angle = TWO_PI / npoints;
  //curveTightness(0.8)
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius;
    let sy = y + sin(a) * radius;
    //curveVertex(sx,sy)
    console.log(a/(PI/3), sx,sy)

    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function polygonSegs(x, y, radius, npoints, segs, strokeWidth) {
  // redoing this whole function
  // calculate 2 hexagons and their endpoints.
  //  create quads that do the thing :D
  let angle = TWO_PI / npoints;
  strokeWeight(0);
  ctx.fillStyle = color(0,0,0)
  for (let a = 0; a < TWO_PI; a += angle) {
    //console.log((a/(PI/3)))
    if (segs[(a/(PI/3))] == 1) { // a/(PI/3) should equal the npoint
      let sx = x + cos(a) * radius;
      let sy = y + sin(a) * radius;
      let fx = x + cos(a+angle) * radius;
      let fy = y + sin(a+angle) * radius;
      let sx1 = x + cos(a) * (radius-strokeWidth);
      let sy1 = y + sin(a) * (radius-strokeWidth);
      let fx1 = x + cos(a+angle) * (radius-strokeWidth);
      let fy1 = y + sin(a+angle) * (radius-strokeWidth);
  
      quad(sx, sy, fx, fy, fx1, fy1, sx1, sy1);
  }
  }
}

function quadPoly(points) { // THERES A FUCKING QUAD() FUNCTION APPARENTLY SO THATS COOL
  // assuming points is a 2d list of 4 2-point arrays.
  beginShape();
  for(i=0; i<4;i+=1) {
    vertex(points[i][0], points[i][1])
  }
  vertex(points[0][0], points[0][1])
  endShape();
}
                   