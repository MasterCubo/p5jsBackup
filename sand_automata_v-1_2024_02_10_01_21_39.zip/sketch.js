let grid = [];
const res = 20; // resolution of simultation
const penSize = 3;
let ctx;
let h = 0;

function setup() {
  colorMode(HSL);
  createCanvas(400, 400);
  for (i = 0; i < res; i += 1) {
    grid.push([]);
    for (j = 0; j < res; j += 1) {
      grid[i].push(0);
    }
  }
  ctx = canvas.getContext("2d");
  //noLoop();
}

function draw() {
  grid[0][9] = 1;
  console.log(grid);

  background(20);
  strokeWeight(0);
  ctx.fillStyle = color(255);

  for (i = 0; i < res; i += 1) {
    for (j = 0; j < res; j += 1) {
      if (grid[i][j] == 1) {
        rect(j * (width / res), i * (height / res), width / res, height / res);
      }
    }
  }
  newGrid = grid.slice().map(function (row) {
    return row.slice();
  });

  // calculate next step

  for (i = 0; i < res; i += 1) {
    for (j = 0; j < res; j += 1) {
      // make em fall
      if (i > 0 && 
          !grid[i][j] == 1 && 
          grid[i - 1][j] == 1
      ) {
        newGrid[i][j] = 1;
        newGrid[i - 1][j] = 0;
        //newGrid[i - 1][j].col = null; // DO THIS FOR THE REST OF THEM
      }
      // make em collapse
      else if (
        i > 0 &&
        j > 0 &&
        j < res - 1 &&
        grid[i][j]==1 &&
        grid[i - 1][j] ==1 &&
        !grid[i][j + 1] ==1 &&
        !grid[i][j - 1]==1
      ) {
        // conditional for validity
        // choose random
        let r = Math.floor(Math.random() * 2);
        // r = 0 or 1
        if (r == 0) {
          // go right
          newGrid[i - 1][j] = 0;
          //newGrid[i - 1][j].col = null;
          newGrid[i][j + 1] = 1;
        }
        if (r == 1) {
          // go left
          newGrid[i - 1][j] = 0;
          //newGrid[i - 1][j].col = null;
          newGrid[i][j - 1] = 1;
        }
      }
      // make em collapse left
      else if (
        i > 0 &&
        j > 0 &&
        grid[i][j]==1 &&
        grid[i - 1][j]==1 &&
        !grid[i][j - 1]==1
      ) {
        newGrid[i - 1][j] = 0;
        //newGrid[i - 1][j].col = null;
        newGrid[i][j - 1]= 1;
      }
      // make em collapse right
      else if (
        i > 0 &&
        j < res - 1 &&
        grid[i][j]==1 &&
        grid[i - 1][j]==1 &&
        !grid[i][j + 1]==1
      ) {
        newGrid[i - 1][j] = 0;
        //newGrid[i - 1][j].col = null;
        newGrid[i][j + 1] = 1;
      }
    }
  }
  grid = newGrid.slice().map(function (row) {
    return row.slice();
  });
}

function mousePressed() {
  draw();
}
