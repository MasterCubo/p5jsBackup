//https://www.youtube.com/watch?v=o9sgjuh-CBM&ab_channel=TheCodingTrain 

let ctx;

function setup() {
  createCanvas(800, 800);
  colorMode(RGB);
  ctx = canvas.getContext('2d');  

}

function draw() {

  background(255);
  rectMode(CORNER)
  strokeWeight(0)
  let bgradient = drawingContext.createLinearGradient(0,0,800,800)
  bgradient.addColorStop(0, color(60,60,60))
  bgradient.addColorStop(1, color(20,20,20))
  ctx.fillStyle = bgradient;
  rect(0,0,800,800, 200)
  
  rectMode(CENTER)
  translate(400,400)
  //textAlign(CENTER)
  //textSize(300)
  //textFont('helvetica')
  //text("cubo",0,50)
  
  let rgradient = drawingContext.createLinearGradient(-300,300,300,-300);
  rgradient.addColorStop(0, color(0,200,255));
  rgradient.addColorStop(1, color(40,0,255));
  ctx.strokeStyle = rgradient;
  ctx.fillStyle = color(0,0,0,0);
  strokeWeight(40);
  rotate(PI/2)
  polygon(0,0,300,6);
  //rotate((-PI/2))
  
  // cubo
  ctx.strokeStyle = color(0,0,0)
  strokeWeight(10)
  // [downleft, left, upleft, upright, right, downright]
  let c =     [1,1,1,1,0,1]
  let u =     [1,1,0,0,1,1]
  let b =     [1,1,1,1,1,1]
  let bstem = [0,1,0,0,0,0]
  let o =     [1,1,1,1,1,1]
  let r = 80;
  polygonSegs(0,(r*3),r,6,c)
  polygonSegs(0,(r*3-2*r),r,6,u)
  polygonSegs(0,(r*3-4*r),r,6,b)
  polygonSegs(-r,(r*3-4*r),r,6,bstem)
  polygonSegs(0,(r*3-6*r),r,6,o)
  
  
}

function polygon(x, y, radius, npoints) {
  let angle = TWO_PI / npoints;
  //curveTightness(0.8)
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius;
    let sy = y + sin(a) * radius;
    //curveVertex(sx,sy)
    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function polygonSegs(x, y, radius, npoints, segs) {
  let angle = TWO_PI / npoints;
  //curveTightness(0.8)
  
  for (let a = 0; a < TWO_PI; a += angle) {
    //console.log((a/(PI/3)))
    if (segs[(a/(PI/3))] == 1) { // a * TWO_PI should equal the npoint
      let sx = x + cos(a) * radius;
      let sy = y + sin(a) * radius;
      let fx = x + cos(a+angle) * radius;
      let fy = y + sin(a+angle) * radius
      //curveVertex(sx,sy)
      line(sx, sy, fx, fy);
  }
  }
}