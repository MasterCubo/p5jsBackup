// looking into it, i think push and pop could have saved me a lot of translating and untranslating and stuff, but im still not sure how they work so

// also as a little addendum blog, I did all of this while on the way to my Visit Day at franiscan. I then made the sand automata on the way back.


let ctx;
const w = 400;
const h = 400;
let img;
let drawImg= false

function preload() {
      img = loadImage('https://raw.githubusercontent.com/MasterCubo/StylishFiles/main/d4f5516259c8aa912d7b729f9efd65b2.png')
}

function setup() {
  createCanvas(w, h);
  colorMode(RGB);
  ctx = canvas.getContext('2d');  
  noLoop(); // this disables the festure to compare the pfp to the new one
  

}

function draw() {
  

  background(255);
  rectMode(CORNER)
  strokeWeight(0)
  let bgradient= drawingContext.createRadialGradient(0,0,w*(150/800),0,0,w*(1100/800))
  // CREATE RADIAL GRADIENT IS A THING ‼️‼️
  bgradient.addColorStop(0, color(90))
  bgradient.addColorStop(1, color(10))
  ctx.fillStyle = bgradient;
  rect(0,0,w,h, w*(218/800))
  
  rectMode(CENTER)
  translate(w/2,w/2)
  //textAlign(CENTER)
  //textSize(300)
  //textFont('helvetica')
  //text("cubo",0,50)
  
  let rgradient = drawingContext.createLinearGradient(-(w*(8/3)),(h*(8/3)),(w*(8/3)),-(h*(8/3))); // changed it to ratios so it can change to any size
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  ctx.fillStyle = color(0,0,0,0);
  strokeWeight(w*(40/800));
  rotate(PI/2)
  //polygon(0,0,300,6);
  
  
  
  
  
  // cubo
  ctx.fillStyle = color(0,0,0)
  strokeWeight(0)
  // [downleft, left, upleft, upright, right, downright]
  let c =     [1,1,1,1,0,1]
  let u =     [1,1,0,0,1,1]
  let b =     [1,1,1,1,1,1]
  let bstem = [0,1,0,0,0,0]
  let o =     [1,1,1,1,1,1]
  let r = w*(75/800);
  let sw = w*(25/800);
  polygonSegs(0,  (r*3),      r,6,c,     sw)
  polygonSegs(0,  (r*3-2*r),  r,6,u,     sw)
  polygonSegs(0,  (r*3-4*r),  r,6,b,     sw)
  polygonSegs(-r, (r*3-4*r),  r,6,bstem, sw)
  polygonSegs(0,  (r*3-6*r),  r,6,o,     sw)
  
  
  
  
  
  
  
  
  //ctx.strokeStyle= color("#f00")
  ctx.fillStyle = color(0,0,0,0)
  strokeWeight(w*(10/800));
  let radius = w*(355/800)
  let angle = TWO_PI / 6;
  const hexCords = {center:      [0,                   0], 
                    bottom:      [cos(0)*radius,       sin(0)*radius], // bottom
                    bottomleft:  [cos(angle)*radius,   sin(angle)*radius], // bottom left
                    upperleft:   [cos(2*angle)*radius, sin(2*angle)*radius], // upper left
                    top:         [cos(3*angle)*radius, sin(3*angle)*radius], // top 
                    upperright:  [cos(4*angle)*radius, sin(4*angle)*radius], // upper right
                    bottomright: [cos(5*angle)*radius, sin(5*angle)*radius], // bottom right
                   }
let scalingVector = 1.03
  let gradientScaler1 = w*(150/800)
  let gradientScaler2 = w*(300/800)
  translate(hexCords.top[0],hexCords.top[1])
  rgradient = drawingContext.createLinearGradient(-gradientScaler1-hexCords.top[0],gradientScaler1-hexCords.top[1],gradientScaler2-hexCords.top[0],-gradientScaler2-hexCords.top[1]);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  scale(1 / scalingVector)
  quadPoly([hexCords.center, hexCords.bottomright, hexCords.bottom,hexCords.bottomleft])// i hate that javascript has no unpacking syntax
  scale(1 * scalingVector)
  translate(-hexCords.top[0],-hexCords.top[1])

  
  
  translate(hexCords.bottomleft[0], hexCords.bottomleft[1])
  rgradient = drawingContext.createLinearGradient(-gradientScaler1-hexCords.bottomleft[0],gradientScaler1-hexCords.bottomleft[1],gradientScaler2-hexCords.bottomleft[0],-gradientScaler2-hexCords.bottomleft[1]);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  scale(1 / scalingVector)
  quadPoly([hexCords.center, hexCords.top, hexCords.upperright, hexCords.bottomright])
  scale(1 * scalingVector)
  translate(-hexCords.bottomleft[0], -hexCords.bottomleft[1])  
    
  
  
  translate(hexCords.bottomright[0], hexCords.bottomright[1])
  rgradient = drawingContext.createLinearGradient(-gradientScaler1-hexCords.bottomright[0],gradientScaler1-hexCords.bottomright[1],gradientScaler2-hexCords.bottomright[0],-gradientScaler2-hexCords.bottomright[1]);
  rgradient.addColorStop(0, color(78, 44, 255));
  rgradient.addColorStop(1, color(26,157,255));
  ctx.strokeStyle = rgradient;
  scale(1 / scalingVector)
  quadPoly([hexCords.center, hexCords.top, hexCords.upperleft, hexCords.bottomleft])
  scale(1 * scalingVector)
  translate(-hexCords.bottomright[0], -hexCords.bottomright[1])

  
  
  //saveCanvas()
  
  
  if(drawImg) {
  rectMode(CORNERS)
  ctx.fillStyle = color("#f00")
  //rect(-w/2,-h/2,w/2,h/2)
  imageMode(CORNERS)
  let transparency = 255
  tint(255,255,255,transparency)
  rotate(-PI/2)
  image(img, -w/2,-h/2, w/2, h/2)
  tint(255,255,255,255)}
  
  
  
}

function mousePressed() {
  drawImg = !drawImg
}

function polygon(x, y, radius, npoints) {
  let angle = TWO_PI / npoints;
  //curveTightness(0.8)
  beginShape();
  for (let a = 0; a < TWO_PI; a += angle) {
    let sx = x + cos(a) * radius;
    let sy = y + sin(a) * radius;
    //curveVertex(sx,sy)
    //console.log(a/(PI/3), sx,sy)

    vertex(sx, sy);
  }
  endShape(CLOSE);
}

function polygonSegs(x, y, radius, npoints, segs, strokeWidth) {
  // redoing this whole function
  // calculate 2 hexagons and their endpoints.
  //  create quads that do the thing :D
  let angle = TWO_PI / npoints;
  strokeWeight(0);
  ctx.fillStyle = color(0,0,0)
  for (let a = 0; a < TWO_PI; a += angle) {
    //console.log((a/(PI/3)))
    if (segs[(a/(PI/3))] == 1) { // a/(PI/3) should equal the npoint
      let sx = x + cos(a) * radius;
      let sy = y + sin(a) * radius;
      let fx = x + cos(a+angle) * radius;
      let fy = y + sin(a+angle) * radius;
      let sx1 = x + cos(a) * (radius-strokeWidth);
      let sy1 = y + sin(a) * (radius-strokeWidth);
      let fx1 = x + cos(a+angle) * (radius-strokeWidth);
      let fy1 = y + sin(a+angle) * (radius-strokeWidth);
  
      quad(sx, sy, fx, fy, fx1, fy1, sx1, sy1);
  }
  }
}

function quadPoly(points) { // THERES A FUCKING QUAD() FUNCTION APPARENTLY SO THATS COOL
  // assuming points is a 2d list of 4 2-point arrays.
  beginShape();
  for(i=0; i<4;i+=1) {
    vertex(points[i][0], points[i][1])
  }
  vertex(points[0][0], points[0][1])
  endShape();
}