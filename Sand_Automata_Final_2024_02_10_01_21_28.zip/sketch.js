// i think coding train did something like this, but i didnt watch it, i just free-balled it. I did all of this while ON tour at Franiscan and on the way back in the car.

let grid = [];
let newGrid = []
const res = 50; // resolution of simultation
const penSize = 3;
let ctx;
let h = 0;

function setup() {
  colorMode(HSL);
  createCanvas(400, 400);
  for (i = 0; i < res; i += 1) {
    grid.push([]);
    for (j = 0; j < res; j += 1) {
      grid[i].push({ full: false, col: 361 });
    }
  }
  ctx = canvas.getContext("2d");

  //noLoop();
}

function draw() {
  //grid[0][25].full = true;
  //grid[0][25].col = h % 360;
  //h += 1;
  //console.log(grid);

  background(20);
  //grid[2][3] = 1
  strokeWeight(0);
  for (i = 0; i < res; i += 1) {
    for (j = 0; j < res; j += 1) {
      if (grid[i][j].full) {
        if (grid[i][j].col == 361) {
          console.log("huh??");
        }
        ctx.fillStyle = color(grid[i][j].col, 50, 50);
        rect(j * (width / res), i * (height / res), width / res, height / res);
      }
    }
  }
  
  for(let i = 0; i < grid.length; i+=1){
    newGrid[i] = JSON.parse(JSON.stringify(grid[i]))
  }

  // calculate next step

  for (let i = 0; i < res; i += 1) {
    for (let j = 0; j < res; j += 1) {
      // make em fall
      if (i > 0 && 
          !grid[i][j].full && 
          grid[i - 1][j].full
      ) {
        newGrid[i][j].full = true;
        newGrid[i][j].col = grid[i - 1][j].col;
        newGrid[i - 1][j].full = false;
      }
      // make em collapse
      else if (
        i > 0 &&
        j > 0 &&
        j < res - 1 &&
        grid[i][j].full &&
        grid[i - 1][j].full &&
        !grid[i][j + 1].full &&
        !grid[i][j - 1].full
      ) {
        // conditional for validity
        // choose random
        let r = Math.floor(Math.random() * 2);
        // r = 0 or 1
        if (r == 0) {
          // go right
          newGrid[i - 1][j].full = false;
          newGrid[i][j + 1].full = true;
          newGrid[i][j + 1].col = grid[i - 1][j].col;
        }
        if (r == 1) {
          // go left
          newGrid[i - 1][j].full = false;
          newGrid[i][j - 1].full = true;
          newGrid[i][j - 1].col = grid[i - 1][j].col;
        }
      }
      // make em collapse left
      else if (
        i > 0 &&
        j > 0 &&
        grid[i][j].full &&
        grid[i - 1][j].full &&
        !grid[i][j - 1].full
      ) {
        newGrid[i - 1][j].full = false;
        newGrid[i][j - 1].full = true;
        newGrid[i][j - 1].col = grid[i - 1][j].col;
      }
      // make em collapse right
      else if (
        i > 0 &&
        j < res - 1 &&
        grid[i][j].full &&
        grid[i - 1][j].full &&
        !grid[i][j + 1].full
      ) {
        newGrid[i - 1][j].full = false;
        newGrid[i][j + 1].full = true;
        newGrid[i][j + 1].col = grid[i - 1][j].col;
      }
    }
  }
  for(let i = 0; i < newGrid.length; i+=1){
    grid[i] = JSON.parse(JSON.stringify(newGrid[i]))
  }
}

function mouseDragged() {
  // find what box the mouse is in. 
  x = Math.floor(mouseX / (width/res))-1
  y = Math.floor(mouseY / (height/res))-1
  grid[y][x]= {full: true, col: h%360}
  h+=1
}
